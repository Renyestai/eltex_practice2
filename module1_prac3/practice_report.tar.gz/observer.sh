#!/bin/bash

CONFIG_FILE="observer.conf"
LOG_FILE="observer.log"


if [ ! -f "$CONFIG_FILE" ]; then
    echo "$(date '+%Y-%m-%d %H:%M:%S') ERROR: Config file $CONFIG_FILE not found" >> "$LOG_FILE"
    exit 1
fi

while IFS= read -r script; do
    [[ -z "$script" || "$script" =~ ^# ]] && continue
    
    if [ ! -f "$script" ]; then
        echo "$(date '+%Y-%m-%d %H:%M:%S') ERROR: Script $script not found" >> "$LOG_FILE"
        continue
    fi
    
    if ! pgrep -f "$script" > /dev/null; then
        echo "$(date '+%Y-%m-%d %H:%M:%S') INFO: Starting $script" >> "$LOG_FILE"
        nohup bash "$script" > /dev/null 2>&1 &
    fi
done < "$CONFIG_FILE"
