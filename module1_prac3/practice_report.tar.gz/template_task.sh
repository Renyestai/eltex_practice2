#!/bin/bash

SCRIPT_NAME=$(basename "$0")
LOG_FILE="report_${SCRIPT_NAME%.*}.log"

if [ "$SCRIPT_NAME" = "template_task.sh" ]; then
    echo "я бригадир, сам не работаю"
    exit 1
fi

echo "[$$] $(date '+%Y-%m-%d %H:%M:%S') Скрипт запущен" >> "$LOG_FILE"

RANDOM_SECONDS=$(( RANDOM % 1771 + 30 ))
sleep $RANDOM_SECONDS

MINUTES=$(( RANDOM_SECONDS / 60 ))
echo "[$$] $(date '+%Y-%m-%d %H:%M:%S') Скрипт завершился, работал $MINUTES минут" >> "$LOG_FILE"
